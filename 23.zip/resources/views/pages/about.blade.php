@extends('main')

@section('content')
	<div class="row">
		<div class="col-md-12">
			<h1>About me</h1>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique, excepturi eaque commodi adipisci sit cumque sequi iste eum magnam corrupti aliquam tempore! Fugit amet hic nihil optio rerum, minus quia non asperiores commodi unde cumque incidunt doloremque nesciunt in? Porro!</p>
		</div>
	</div>
@endsection