<?php $__env->startSection('stylesheets'); ?>
<link rel="stylesheet" type="text/css" href="styles.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="jumbotron">
			<h1>Welcome to my Blog</h1>
			<p class="lead">Thank you for visiting our website. This is my test website built with Laravel and Bootstrap!</p>
			<p><a class="btn btn-primary btn-lg" href="#" role="button">Popular Post</a></p>
		</div>
	</div>
</div> <!--end of header .row-->

<div class="row">
	<div class="col-md-8">

		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="post">
			<h3><?php echo e($post->title); ?></h3>
			<p><?php echo e(substr($post->body, 0, $a=3e2)); ?><?php echo e(strlen($post->body)>$a?"...":""); ?></p>
			<a href="#" class="btn btn-primary">Read More</a>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>

	<div class="col-md-3 col-md-offset-1">
		<h2>sidebar</h2>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
			<script>
				
			</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>