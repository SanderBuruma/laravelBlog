<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<h1>About me</h1>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique, excepturi eaque commodi adipisci sit cumque sequi iste eum magnam corrupti aliquam tempore! Fugit amet hic nihil optio rerum, minus quia non asperiores commodi unde cumque incidunt doloremque nesciunt in? Porro!</p>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>