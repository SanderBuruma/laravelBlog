
		<hr>

		<p class="text-center">Copyright Sander Buruma - all Rights Reserved</p>
