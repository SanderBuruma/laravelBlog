<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['middleware' => ['web']], function () {

	//login/out Routes...
	Route::get('login', ['as' => 'login', 'uses' => 'Auth\LoginController@showLoginForm'])->name('login'); 
	Route::post('login', 'Auth\LoginController@login'); 
	Route::get('/logout','Auth\LoginController@logout')->name('logout');
	//I just figure out our problem. Add this route in web.php Route::get('/logout','Auth\LoginController@logout' ); And don't change in LoginController 'except ('logout')' with 'except('getLogout') because that is solved in new versions of Laravel. Maybe in next videos, when we add button for logout, that route will not be necessary. By documentation we must had a POST route for logout: "The Auth::routes method now registers a POST route for /logout instead of a GET route. This prevents other web applications from logging your users out of your application. To upgrade, you should either convert your logout requests to use the POST verb or register your own GET routefor the /logout URI"
	
	// Registration Routes... 
	Route::get('register', 'Auth\RegisterController@showRegistrationForm')->name('register'); 
	Route::post('register', 'Auth\RegisterController@register'); 
	
	// Password Reset Routes... 
	Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request'); 
	Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email'); 
	Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset'); 
	Route::post('password/reset', 'Auth\ResetPasswordController@reset');

	//password reset routes
	Route::get('password/reset/{token?}');
	Route::post('password/email');

	//various
	Route::get('blog/{slug}', ['as' => 'blog.single', 'uses'=>'BlogController@getSingle'])->where('slug', '[\w\d\-\_]+');
	Route::get('blog', ['uses'=>'BlogController@getIndex', 'as' => 'blog.index']);
	Route::get('contact','PagesController@getContact');
	Route::get('about','PagesController@getAbout');
	Route::get('/','PagesController@getIndex');
	Route::resource('posts', 'PostController');
});
Auth::routes();
