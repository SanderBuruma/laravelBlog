<?php $__env->startSection('title', '| View Post - '.$post->slug); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-8">
		<h1><?php echo e($post->title); ?></h1>

		<p class="lead"><?php echo e($post->body); ?></p>
	</div>
	<div class="col-md-4">
		<div class="jumbotron">
			<dl class="dl-horizontal">
				<label>Url: </label>
				<a href="<?php echo e(url("blog/$post->slug")); ?>"><?php echo e($post->slug); ?></a>
			</dl>
			<dl class="dl-horizontal">
				<label>Created At: </label>
				<p><?php echo e(date('M j, Y - H:i',strtotime($post->created_at))); ?></p>
			</dl>
			<dl class="dl-horizontal">
				<label>Last Updated: </label>
				<p><?php echo e(date('M j, Y - H:i', strtotime($post->updated_at))); ?></p>
			</dl>
			<hr>
			<div class="row">
				<div class="col-sm-6">
					<?php echo Html::linkRoute('posts.edit', 'Edit', array($post->id), array('class'=>'btn btn-primary btn-block')); ?>

				</div>
				<div class='col-sm-6'>
					<?php echo Form::open(['route' => ['posts.destroy', $post->id], 'method' => 'DELETE']); ?>

					
					<?php echo Form::submit('Delete', ['class'=>'btn btn-danger btn-block ']); ?>

					
					<?php echo Form::close(); ?>

				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?php echo e(Html::linkRoute('posts.index', '<<see all posts', [], ['class' => 'btn btn-secondary btn-block btn-h1-spacing btn-see-all'])); ?>

				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>