<h3>contact form:</h3>

<div>
	{{ $bodyMessage }}
</div>
<p>Sent via {{ $email }}</p>