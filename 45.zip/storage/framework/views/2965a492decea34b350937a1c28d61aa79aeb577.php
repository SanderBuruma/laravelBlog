<?php $__env->startSection('title', '| Edit Post'); ?>
<?php $__env->startSection('stylesheets'); ?>

<?php echo Html::style('css/select2.min.css'); ?>


<script src='https://cloud.tinymce.com/stable/tinymce.min.js'></script>
<script>
	tinymce.init({
		selector: 'textarea',
		plugins: 'link code image',
		branding: false,
		menubar: false
	});
</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-8">
		<?php echo Form::model($post, ['route' => ['posts.update', $post->id], 'method' => 'PATCH']); ?>


		<?php echo e(Form::label('title', 'Title:')); ?>

		<?php echo e(Form::text('title', null, ["class"=>'form-control form-control-lg'])); ?>


		<?php echo e(Form::label('slug', 'Slug:', ['class'=>'form-spacing-top'])); ?>

		<?php echo e(Form::text('slug', null, ["class"=>'form-control'])); ?>

		<br>
		<?php echo e(Form::label('category_id', 'ID:')); ?>

		<?php echo e(Form::select('category_id', $cats, null, ['class' => 'form-control'])); ?>

		<br>
		<select class="tag-multiple-select form-control" name="tags[]" multiple="multiple">
			<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>

		<?php echo e(Form::label('body', 'Body:', ['class'=>'form-spacing-top'])); ?>

		<?php echo e(Form::textarea('body', null,  ['class'=>'form-control'])); ?>

	</div>
	<div class="col-md-4">
		<div class="jumbotron">
			<dl class="dl-horizontal">
				<dt>Created At: </dt>
				<dd><?php echo e(date('M j, Y - H:i',strtotime($post->created_at))); ?></dd>
			</dl>
			<dl class="dl-horizontal">
				<dt>Last Updated: </dt>
				<dd><?php echo e(date('M j, Y - H:i', strtotime($post->updated_at))); ?></dd>
			</dl>
			<hr>
			<div class="row">
				<div class="col-sm-6">
					<?php echo Html::linkRoute('posts.show', 'Cancel', array($post->id), array('class'=>'btn btn-danger btn-block')); ?>

				</div>
				<div class='col-sm-6'>
					<?php echo e(Form::submit('Save Changes', ['class'=>'btn btn-success btn-block'])); ?>

				</div>
			</div>
		</div>
		<?php echo Form::close(); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
 
<?php echo Html::script('js/select2.min.js'); ?>


<script>

	$(document).ready(function() {
		$('.tag-multiple-select').select2();
	});

	$('.tag-multiple-select').select2().val(<?php echo json_encode($post->tags()->allRelatedIds()); ?>).trigger('change');

</script>

<?php $__env->stopSection(); ?>	
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>