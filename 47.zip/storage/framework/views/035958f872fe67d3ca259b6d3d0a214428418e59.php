<h3>contact form:</h3>

<div>
	<?php echo e($bodyMessage); ?>

</div>
<p>Sent via <?php echo e($email); ?></p>