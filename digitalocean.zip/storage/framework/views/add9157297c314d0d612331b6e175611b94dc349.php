<?php $__env->startSection('title', '| Reset Password'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-6 offset-md-3">
        <div class="card card-default">
            <div class="card-header">
                Reset Password
            </div>
            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php echo Form::open(['url'=>'password/email', 'method'=>"POST"]); ?>


                <?php echo Form::label('email', 'Email Address'); ?>

                <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

                <br>
                <?php echo Form::submit('Reset Password', ['class'=>'btn btn-primary']); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>